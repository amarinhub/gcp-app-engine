var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ProductSchema = new Schema({
    name: {type: String, required: true, max: 100},
    price: {type: Number, required: true },
});

const Product = mongoose.model('Product', ProductSchema);

exports.ProductSchema = ProductSchema;
exports.Product = Product; 