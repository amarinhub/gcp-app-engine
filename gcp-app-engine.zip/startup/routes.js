const express = require('express');
const error = require('../middleware/error');

/** Declared routes */
var product = require('../routes/product'); // Imports routes for the products
var customer = require('../routes/customer'); // Imports routes for the customer
var test = require('../routes/test'); // Imports routes for the products

module.exports = function(app){
    app.use(express.json());
    app.use('/api', test);
    app.use('/mlab', product);
    app.use('/datastore', customer);
    app.use(error);
};