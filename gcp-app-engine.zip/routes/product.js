/** Important */
var express = require('express');
var router = express.Router();
const { Product } = require('../database/models/product');

/** http://localhost:8081/mlab/getcustomers */
router.get('/getCustomers', async (req, res) => {
    await Product.find({}, function (err, customers) {
        res.send(customers);
    });
});


/** http://localhost:8081/mlab/getcustomer?id=5d6f97c17c213e60b8f89266 */
router.get('/getCustomer', async (req, res) => {
    const product = await Product.findById(req.query.id);
  
    if (!product) return res.status(404).send('The product with the given ID was not found.');
  
    res.send(product);
});


router.put('/customer/:id/update', async (req, res) => {
    const { error } = false; // validate(req.body); 
    if (error) return res.status(400).send(error.details[0].message);
  
    const product = await Product.findByIdAndUpdate(req.params.id, { name: req.body.name , price: req.body.price});
  
    if (!product) return res.status(404).send('The product with the given ID was not found.');
    
    res.send(product);
});

/** http://localhost:8081/api/product/5d6f98447c213e60b8f892a9/delete */
router.delete('/customer/:id/delete', async (req, res) => {
    console.log("Deleting...");
    var id = req.params.id;
    const product = await Product.findByIdAndRemove(req.params.id);
    
    if (!product) return res.status(404).send('The product with the given ID was not found.');
  
    res.json({ success: id })
});

module.exports = router;