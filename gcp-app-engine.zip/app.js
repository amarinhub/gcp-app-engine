// NodeJS modules for Express app - installed with NPM
var express = require('express');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var winston = require('./startup/logging');
var morgan = require('morgan');
var cors = require('cors');

// Create the Express app 
var app = express();

app.use(morgan('combined', { stream: winston.stream }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(cors());

/** StartUp modules to Load */
require('./startup/contextDb')();
require('./middleware/async')(app);
require('./startup/routes')(app);

module.exports = app;