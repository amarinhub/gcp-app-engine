/** Important */
var express = require('express');
var router = express.Router();

const model = require('../database/cloud-datastore');

/**
 * GET http://localhost:8081/datastore/getcustomers
 *     https://hale-post-251906.appspot.com/datastore/getcustomers
 * Retrieve a page of books (up to ten at a time).
 */
router.get('/getcustomers', async (req, res, next) => {
    model.list(10, (err, entities) => {
        if (err) {
            next(err);
            return;
        }
        res.json({
            items: entities
        });
    });
});

/**
* GET GET http://localhost:8081/datastore/getcustomers?id=5629499534213120
*         https://hale-post-251906.appspot.com/datastore/getcustomerId?id=5629499534213120  
* Retrieve a book.
*/
router.get('/getcustomerId', async (req, res, next) => {
    model.read(req.query.id, (err, entity) => {
        if (err) {
            next(err);
            return;
        }
        res.json(entity);
    });
});

router.use((err, req, res, next) => {
    // Format error and forward to generic error handler for logging and
    // responding to the request
    err.response = {
      message: err.message,
      internalCode: err.code,
    };
    next(err);
  });

module.exports = router;