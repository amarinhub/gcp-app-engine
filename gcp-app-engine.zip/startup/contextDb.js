// Setting up mLAb - MongoDB connection
var mongoose = require('mongoose');
//var prod_db_url = 'mongodb://user:password@@ds143262.mlab.com:43262/google-cloud-platform';';
const dev_db_url = "mongodb://test:Test123456@ds143262.mlab.com:43262/google-cloud-platform";
//var mongoDB = process.env.MONGODB_URI || dev_db_url;
var mongoDB = dev_db_url;



module.exports = function(){
    mongoose.connect(mongoDB , { useNewUrlParser: true });
    mongoose.Promise = global.Promise;
    var db = mongoose.connection;
    db.on('error', console.error.bind(console, 'MongoDB connection error:'));
}