/** Important */
var express = require('express');
var router = express.Router();
require('../middleware/async');


// localhost:8081/test
router.get('/test', async(req, res) => {
    res.send('Greetings from the Test controller!');
});

module.exports = router;